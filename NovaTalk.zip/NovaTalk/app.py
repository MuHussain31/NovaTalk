import streamlit as st
import requests

st.set_page_config(page_title="NovaTalk", page_icon="💬", layout="wide")

# Sidebar
st.sidebar.image("logo.jpg", width=150)
st.sidebar.title("NovaTalk")
st.sidebar.write("Your AI Chat Assistant 🚀")
model_choice = st.sidebar.selectbox("Choose Model", ["tinyllama", "llama2", "llama3"])
st.sidebar.markdown("---")
st.sidebar.write("Made with ❤️ for internship project")

# Title
st.markdown(
    "<h1 style='text-align: center; color: #4CAF50;'>💬 NovaTalk</h1>",
    unsafe_allow_html=True
)

# Initialize chat history
if "messages" not in st.session_state:
    st.session_state.messages = []

# Function to query Ollama
def get_ollama_response(prompt, model):
    response = requests.post(
        "http://localhost:11434/api/generate",
        json={
            "model": model,
            "prompt": prompt,
            "stream": False
        }
    )
    if response.status_code == 200:
        return response.json()["response"]
    else:
        return "❌ Error: Could not get a response from the model."

# Chat input
user_input = st.chat_input("Type your message...")

# If user sends a message
if user_input:
    st.session_state.messages.append({"role": "user", "content": user_input})

    with st.spinner("🤖 Thinking..."):
        reply = get_ollama_response(user_input, model_choice)

    st.session_state.messages.append({"role": "assistant", "content": reply})

# Display chat
for message in st.session_state.messages:
    if message["role"] == "user":
        with st.chat_message("user"):
            st.markdown(
                f"<div style='background-color:#4CAF50;color:white;padding:10px;border-radius:10px;max-width:80%;'>{message['content']}</div>",
                unsafe_allow_html=True
            )
    else:
        with st.chat_message("assistant"):
            st.markdown(
                f"<div style='background-color:#2C2C2C;color:white;padding:10px;border-radius:10px;max-width:80%;'>{message['content']}</div>",
                unsafe_allow_html=True
            )
